import React from "react";
import "../../../Style/styles.css"
export default function EstudiantesNoRealizaronTest() {
  return (
    <div>
  
  <div>
  <table class="table">
  <caption></caption>
  <thead>
    <tr>
      <th scope="col"></th>
      <th scope="col">Nombre</th>
      <th scope="col">Correo</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row"></th>
      <td>Javier Gonzalez</td>
      <td>javierjose2555@gmail.com</td>
  
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Brayan Tafur</td>
      <td>BrayanTafur929@gmail.com</td>
     
    </tr>
    <tr>
      <th scope="row"></th>
      <td>Juliana Ibarguen</td>
      <td>Julianarda@gmail.com</td>
    
    </tr>
  </tbody>
</table>
  </div>
    </div>
  );
}