import React from "react";
import CInicio from "../Components/CInicio";
export default function Inicio() {
  return (
    <div>
      <CInicio />

    </div>
  );
}
