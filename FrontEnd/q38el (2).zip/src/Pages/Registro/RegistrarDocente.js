import React from "react";
import Registro from "../../Components/CRegistro";
export default function RegistrarDocente() {
  return (
    <div>
      <Registro />
      <button id="botd" type="submit" class="btn btn-primary">
        <a id="bd" href="Logins">
          Registrarse
        </a>
      </button>
    </div>
  );
}
