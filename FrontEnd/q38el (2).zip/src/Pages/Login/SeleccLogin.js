import React from "react";
import CSeleccLogin from "../../Components/CSeleccLogin";

export default function Logins() {
  return (
    <div>
      <CSeleccLogin />
    </div>
  );
}



  