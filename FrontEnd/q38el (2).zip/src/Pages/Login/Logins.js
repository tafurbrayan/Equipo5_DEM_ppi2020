import React from "react";
import CLogins from "../../Components/CLogins";

export default function Logins() {
  return (
    <div>
      <CLogins />
    </div>
  );
}
